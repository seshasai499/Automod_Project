// phase2~init1.c
// AutoMod 12.6.1 Generated File
// Build: 12.6.1.12
// Model name:	phase2
// Model path:	C:\Users\Administrator\Documents\semiconducter\Semi phase 2 zip\Semi phase 2\phase2.dir\
// Generated:	Wed Nov 27 00:39:48 2024
// Applied/AutoMod Licensee Confidential
// NO DISTRIBUTION OR REPRODUCTION RIGHTS GRANTED!
// Copyright (c) 1988-2015 Applied Materials All rights reserved.
//
// All Rights Reserved.  Reproduction or transmission in whole or
// in part, in any form or by any means, electronic, mechanical or
// otherwise, is prohibited without the prior written consent of
// copyright owner.
//
// Licensed Material - Property of Applied Materials, Inc.
//
// Applied Materials, Inc.
// 3050 Bowers Drive
// P.O. Box 58039
// Santa Clara, CA 95054-3299
// U.S.A.
//


#include "decls.h"

void
initglobs0()
{
	am_model.$sys = model;
	am_model.am_SMS.$sys = symGetSystemDataByName(am_model.$sys, "SMS");
	am_model.am_SMS.am_T3_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T3_OUT");
	am_model.am_SMS.am_T4_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T4_OUT");
	am_model.am_SMS.am_T5_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T5_OUT");
	am_model.am_SMS.am_INTER_ETCH = symGetSystemDataByName(am_model.am_SMS.$sys, "INTER_ETCH");
	am_model.am_SMS.am_T6_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T6_OUT");
	am_model.am_SMS.am_VEHICLE_INTER = symGetSystemDataByName(am_model.am_SMS.$sys, "VEHICLE_INTER");
	am_model.am_SMS.am_T7_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T7_OUT");
	am_model.am_SMS.am_LITHO_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "LITHO_IN");
	am_model.am_SMS.am_T1_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T1_OUT");
	am_model.am_SMS.am_T2_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T2_OUT");
	am_model.am_SMS.am_VEHICLE_DIFF = symGetSystemDataByName(am_model.am_SMS.$sys, "VEHICLE_DIFF");
	am_model.am_SMS.am_T8_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T8_OUT");
	am_model.am_SMS.am_T9_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T9_OUT");
	am_model.am_SMS.am_DefSegment = symGetSystemDataByName(am_model.am_SMS.$sys, "DefSegment");
	am_model.am_SMS.am_VEHICLE_LITHO = symGetSystemDataByName(am_model.am_SMS.$sys, "VEHICLE_LITHO");
	am_model.am_SMS.am_CMP_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "CMP_OUT");
	am_model.am_SMS.am_CMP_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "CMP_IN");
	am_model.am_SMS.am_VEHICLE_CMP = symGetSystemDataByName(am_model.am_SMS.$sys, "VEHICLE_CMP");
	am_model.am_SMS.am_INTER_LITHO = symGetSystemDataByName(am_model.am_SMS.$sys, "INTER_LITHO");
	am_model.am_SMS.am_T18_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T18_OUT");
	am_model.am_SMS.am_T35_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T35_IN");
	am_model.am_SMS.am_T37_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T37_OUT");
	am_model.am_SMS.am_T28_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T28_OUT");
	am_model.am_SMS.am_T19_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T19_OUT");
	am_model.am_SMS.am_T34_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T34_IN");
	am_model.am_SMS.am_VEHICLE_ETCH = symGetSystemDataByName(am_model.am_SMS.$sys, "VEHICLE_ETCH");
	am_model.am_SMS.am_T29_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T29_OUT");
	am_model.am_SMS.am_T36_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T36_OUT");
	am_model.am_SMS.am_T28_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T28_IN");
	am_model.am_SMS.am_T37_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T37_IN");
	am_model.am_SMS.am_T35_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T35_OUT");
	am_model.am_SMS.am_T18_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T18_IN");
	am_model.am_SMS.am_T36_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T36_IN");
	am_model.am_SMS.am_T29_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T29_IN");
	am_model.am_SMS.am_T19_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T19_IN");
	am_model.am_SMS.am_T34_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T34_OUT");
	am_model.am_SMS.am_LITHO_PARK = symGetSystemDataByName(am_model.am_SMS.$sys, "LITHO_PARK");
	am_model.am_SMS.am_T14_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T14_OUT");
	am_model.am_SMS.am_T26_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T26_IN");
	am_model.am_SMS.am_T24_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T24_OUT");
	am_model.am_SMS.am_T16_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T16_IN");
	am_model.am_SMS.am_T27_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T27_IN");
	am_model.am_SMS.am_T15_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T15_OUT");
	am_model.am_SMS.am_T25_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T25_OUT");
	am_model.am_SMS.am_T17_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T17_IN");
	am_model.am_SMS.am_T16_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T16_OUT");
	am_model.am_SMS.am_T24_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T24_IN");
	am_model.am_SMS.am_T26_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T26_OUT");
	am_model.am_SMS.am_T14_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T14_IN");
	am_model.am_SMS.am_INTER_DIFF = symGetSystemDataByName(am_model.am_SMS.$sys, "INTER_DIFF");
	am_model.am_SMS.am_T17_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T17_OUT");
	am_model.am_SMS.am_T25_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T25_IN");
	am_model.am_SMS.am_DIFF_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "DIFF_OUT");
	am_model.am_SMS.am_T15_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T15_IN");
	am_model.am_SMS.am_T27_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T27_OUT");
	am_model.am_SMS.am_T30_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T30_OUT");
	am_model.am_SMS.am_T21_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T21_OUT");
	am_model.am_SMS.am_T13_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T13_IN");
	am_model.am_SMS.am_T11_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T11_OUT");
	am_model.am_SMS.am_T23_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T23_IN");
	am_model.am_SMS.am_T22_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T22_OUT");
	am_model.am_SMS.am_T12_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T12_OUT");
	am_model.am_SMS.am_T23_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T23_OUT");
	am_model.am_SMS.am_T11_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T11_IN");
	am_model.am_SMS.am_T13_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T13_OUT");
	am_model.am_SMS.am_T21_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T21_IN");
	am_model.am_SMS.am_T30_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T30_IN");
	am_model.am_SMS.am_T12_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T12_IN");
	am_model.am_SMS.am_CMP_PARK = symGetSystemDataByName(am_model.am_SMS.$sys, "CMP_PARK");
	am_model.am_SMS.am_T22_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T22_IN");
	am_model.am_SMS.am_T32_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T32_IN");
	am_model.am_SMS.am_T33_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T33_OUT");
	am_model.am_SMS.am_T10_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T10_IN");
	am_model.am_SMS.am_T20_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T20_IN");
	am_model.am_SMS.am_T31_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T31_IN");
	am_model.am_SMS.am_T32_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T32_OUT");
	am_model.am_SMS.am_LITHO_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "LITHO_OUT");
	am_model.am_SMS.am_T31_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T31_OUT");
	am_model.am_SMS.am_T20_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T20_OUT");
	am_model.am_SMS.am_ETCH_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "ETCH_OUT");
	am_model.am_SMS.am_T10_OUT = symGetSystemDataByName(am_model.am_SMS.$sys, "T10_OUT");
	am_model.am_SMS.am_T33_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T33_IN");
	am_model.am_SMS.am_DIFF_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "DIFF_IN");
	am_model.am_SMS.am_parentsys = symGetSystemDataByName(am_model.am_SMS.$sys, "parentsys");
	am_model.am_SMS.am_INTER_PARK = symGetSystemDataByName(am_model.am_SMS.$sys, "INTER_PARK");
	am_model.am_SMS.am_INTER_CMP = symGetSystemDataByName(am_model.am_SMS.$sys, "INTER_CMP");
	am_model.am_SMS.am_T9_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T9_IN");
	am_model.am_SMS.am_T8_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T8_IN");
	am_model.am_SMS.am_ETCH_PARK = symGetSystemDataByName(am_model.am_SMS.$sys, "ETCH_PARK");
	am_model.am_SMS.am_T3_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T3_IN");
	am_model.am_SMS.am_ETCH_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "ETCH_IN");
	am_model.am_SMS.am_T4_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T4_IN");
	am_model.am_SMS.am_T6_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T6_IN");
	am_model.am_SMS.am_T5_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T5_IN");
	am_model.am_SMS.am_T7_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T7_IN");
	am_model.am_SMS.am_DIFF_PARK = symGetSystemDataByName(am_model.am_SMS.$sys, "DIFF_PARK");
	am_model.am_SMS.am_T2_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T2_IN");
	am_model.am_SMS.am_T1_IN = symGetSystemDataByName(am_model.am_SMS.$sys, "T1_IN");
	am_model.am_die = symGetSystemDataByName(am_model.$sys, "die");
	am_model.am_stream_LoadA_1 = symGetSystemDataByName(am_model.$sys, "stream_LoadA_1");
	am_model.am_Makespan$att = symGetSystemDataByName(am_model.$sys, "Makespan");
	am_model.am_TOOLS = symGetSystemDataByName(am_model.$sys, "TOOLS");
	am_model.am_OPCTimestamp$var = symGetSystemDataByName(am_model.$sys, "OPCTimestamp");
	am_model.am_OPCTimestamp$var->data = (void*)&am_model.am_OPCTimestamp;
	am_model.am_P_Enter_A = symGetSystemDataByName(am_model.$sys, "P_Enter_A");
	am_model.am_modelsys = symGetSystemDataByName(am_model.$sys, "modelsys");
	am_model.am_P_Proc_A = symGetSystemDataByName(am_model.$sys, "P_Proc_A");
	am_model.am_stream_TOOLS_1 = symGetSystemDataByName(am_model.$sys, "stream_TOOLS_1");
	am_model.am_stream0 = symGetSystemDataByName(am_model.$sys, "stream0");
	am_model.am_Queue = symGetSystemDataByName(am_model.$sys, "Queue");
	am_model.am_OPCQuality$var = symGetSystemDataByName(am_model.$sys, "OPCQuality");
	am_model.am_OPCQuality$var->data = (void*)&am_model.am_OPCQuality;
	model_Source_init(&am_model);
	{
		Iter(List, FileList) it = Begin(List, FileList, &((ProcSystem*)am_model.$sys)->files);

	}
	{
		Iter(List, AMTypeList) it = Begin(List, AMTypeList, &((ProcSystem*)am_model.$sys)->types);

		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(Acceleration);
		IterValue(List, AMTypeList, it)->valstrfunc = Acceleration_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc = str2String;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(block*);
		IterValue(List, AMTypeList, it)->valstrfunc = BlockPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))BlockPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMBlockList*);
		IterValue(List, AMTypeList, it)->valstrfunc = BlockList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(ASI_Color);
		IterValue(List, AMTypeList, it)->valstrfunc = Color_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))Color_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(Container*);
		IterValue(List, AMTypeList, it)->valstrfunc = ContainerPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))ContainerPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMContainerList*);
		IterValue(List, AMTypeList, it)->valstrfunc = ContainerList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(counter*);
		IterValue(List, AMTypeList, it)->valstrfunc = CounterPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))CounterPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(Distance);
		IterValue(List, AMTypeList, it)->valstrfunc = Distance_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc = str2String;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(iofile*);
		IterValue(List, AMTypeList, it)->valstrfunc = FilePtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))FilePtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(bgraph*);
		IterValue(List, AMTypeList, it)->valstrfunc = GraphPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))GraphPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(int32);
		IterValue(List, AMTypeList, it)->valstrfunc = Integer_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc = str2String;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(label*);
		IterValue(List, AMTypeList, it)->valstrfunc = LabelPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))LabelPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(load*);
		IterValue(List, AMTypeList, it)->valstrfunc = LoadPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))LoadPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMLoadList*);
		IterValue(List, AMTypeList, it)->valstrfunc = LoadList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(loadtype*);
		IterValue(List, AMTypeList, it)->valstrfunc = LoadTypePtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))LoadTypePtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(simloc*);
		IterValue(List, AMTypeList, it)->valstrfunc = Location_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))Location_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMLocationList*);
		IterValue(List, AMTypeList, it)->valstrfunc = LocationList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(LocationType*);
		IterValue(List, AMTypeList, it)->valstrfunc = LocationTypePtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))LocationTypePtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMLocationTypeList*);
		IterValue(List, AMTypeList, it)->valstrfunc = LocationTypeList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(State_machine*);
		IterValue(List, AMTypeList, it)->valstrfunc = MonitorPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))MonitorPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterInc(List, AMTypeList, it);
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(ConvMotor*);
		IterValue(List, AMTypeList, it)->valstrfunc = MotorPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))MotorPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMConvMotorList*);
		IterValue(List, AMTypeList, it)->valstrfunc = MotorList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(MotorType*);
		IterValue(List, AMTypeList, it)->valstrfunc = MotorTypePtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))MotorTypePtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMMotorTypeList*);
		IterValue(List, AMTypeList, it)->valstrfunc = MotorTypeList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(ordlist*);
		IterValue(List, AMTypeList, it)->valstrfunc = OrderListPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))OrderListPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(Path*);
		IterValue(List, AMTypeList, it)->valstrfunc = PathPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))PathPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMPathList*);
		IterValue(List, AMTypeList, it)->valstrfunc = PathList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AgvPathType*);
		IterValue(List, AMTypeList, it)->valstrfunc = PathTypePtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))PathTypePtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMAgvPathTypeList*);
		IterValue(List, AMTypeList, it)->valstrfunc = PathTypeList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(Photoeye*);
		IterValue(List, AMTypeList, it)->valstrfunc = PhotoeyePtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))PhotoeyePtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMPhotoList*);
		IterValue(List, AMTypeList, it)->valstrfunc = PhotoeyeList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(PhotoeyeType*);
		IterValue(List, AMTypeList, it)->valstrfunc = PhotoeyeTypePtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))PhotoeyeTypePtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMPhotoeyeTypeList*);
		IterValue(List, AMTypeList, it)->valstrfunc = PhotoeyeTypeList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(process*);
		IterValue(List, AMTypeList, it)->valstrfunc = ProcessPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))ProcessPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(queue*);
		IterValue(List, AMTypeList, it)->valstrfunc = QueuePtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))QueuePtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMQueueList*);
		IterValue(List, AMTypeList, it)->valstrfunc = QueueList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(Rate);
		IterValue(List, AMTypeList, it)->valstrfunc = Rate_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc = str2String;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(double);
		IterValue(List, AMTypeList, it)->valstrfunc = Real_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc = str2String;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(resource*);
		IterValue(List, AMTypeList, it)->valstrfunc = ResourcePtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))ResourcePtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMResourceList*);
		IterValue(List, AMTypeList, it)->valstrfunc = ResourceList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(SchedJob*);
		IterValue(List, AMTypeList, it)->valstrfunc = SchedJobPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))SchedJobPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMSchedJobList*);
		IterValue(List, AMTypeList, it)->valstrfunc = SchedJobList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(ConvSection*);
		IterValue(List, AMTypeList, it)->valstrfunc = SectionPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))SectionPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMConvSectionList*);
		IterValue(List, AMTypeList, it)->valstrfunc = SectionList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(ConvSectionType*);
		IterValue(List, AMTypeList, it)->valstrfunc = SectionTypePtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))SectionTypePtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMConvSectionTypeList*);
		IterValue(List, AMTypeList, it)->valstrfunc = SectionTypeList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterInc(List, AMTypeList, it);
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(States*);
		IterValue(List, AMTypeList, it)->valstrfunc = StatePtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))StatePtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(rnstream*);
		IterValue(List, AMTypeList, it)->valstrfunc = StreamPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))StreamPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(char*);
		IterValue(List, AMTypeList, it)->valstrfunc = String_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc = str2String;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMStringList*);
		IterValue(List, AMTypeList, it)->valstrfunc = StringList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(System*);
		IterValue(List, AMTypeList, it)->valstrfunc = SystemPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))SystemPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(table*);
		IterValue(List, AMTypeList, it)->valstrfunc = TablePtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))TablePtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(ASITime);
		IterValue(List, AMTypeList, it)->valstrfunc = Time_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc = str2String;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(ConvTransfer*);
		IterValue(List, AMTypeList, it)->valstrfunc = TransferPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))TransferPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(TransferType*);
		IterValue(List, AMTypeList, it)->valstrfunc = TransferTypePtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))TransferTypePtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(vehicle*);
		IterValue(List, AMTypeList, it)->valstrfunc = VehiclePtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))VehiclePtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMVehicleList*);
		IterValue(List, AMTypeList, it)->valstrfunc = VehicleList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterInc(List, AMTypeList, it);
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(VehSeg*);
		IterValue(List, AMTypeList, it)->valstrfunc = VehSegPtr_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc  = (void (*)(char*))VehSegPtr_strvalfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(AMVehSegList*);
		IterValue(List, AMTypeList, it)->valstrfunc = VehSegList_valstrfunc;
		IterInc(List, AMTypeList, it);
		IterValue(List, AMTypeList, it)->size = sizeof(Velocity);
		IterValue(List, AMTypeList, it)->valstrfunc = Velocity_valstrfunc;
		IterValue(List, AMTypeList, it)->strvalfunc = str2String;
	}

}

