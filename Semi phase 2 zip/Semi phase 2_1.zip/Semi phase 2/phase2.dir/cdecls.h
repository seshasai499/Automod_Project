// cdecls.h
// AutoMod 12.6.1 Generated File
// Build: 12.6.1.12
// Model name:	phase2
// Model path:	C:\Users\Administrator\Documents\semiconducter\Semi phase 2 zip\Semi phase 2\phase2.dir\
// Generated:	Wed Nov 27 00:39:48 2024
// Applied/AutoMod Licensee Confidential
// NO DISTRIBUTION OR REPRODUCTION RIGHTS GRANTED!
// Copyright (c) 1988-2015 Applied Materials All rights reserved.
//
// All Rights Reserved.  Reproduction or transmission in whole or
// in part, in any form or by any means, electronic, mechanical or
// otherwise, is prohibited without the prior written consent of
// copyright owner.
//
// Licensed Material - Property of Applied Materials, Inc.
//
// Applied Materials, Inc.
// 3050 Bowers Drive
// P.O. Box 58039
// Santa Clara, CA 95054-3299
// U.S.A.
//


#include "decls.h"

#undef am2_T3_OUT
#define am2_T3_OUT am_model.am_SMS.am_T3_OUT
#undef am2_T4_OUT
#define am2_T4_OUT am_model.am_SMS.am_T4_OUT
#undef am2_T5_OUT
#define am2_T5_OUT am_model.am_SMS.am_T5_OUT
#undef am2_INTER_ETCH
#define am2_INTER_ETCH am_model.am_SMS.am_INTER_ETCH
#undef am2_T6_OUT
#define am2_T6_OUT am_model.am_SMS.am_T6_OUT
#undef am2_VEHICLE_INTER
#define am2_VEHICLE_INTER am_model.am_SMS.am_VEHICLE_INTER
#undef am2_T7_OUT
#define am2_T7_OUT am_model.am_SMS.am_T7_OUT
#undef am2_LITHO_IN
#define am2_LITHO_IN am_model.am_SMS.am_LITHO_IN
#undef am2_T1_OUT
#define am2_T1_OUT am_model.am_SMS.am_T1_OUT
#undef am2_T2_OUT
#define am2_T2_OUT am_model.am_SMS.am_T2_OUT
#undef am2_VEHICLE_DIFF
#define am2_VEHICLE_DIFF am_model.am_SMS.am_VEHICLE_DIFF
#undef am2_T8_OUT
#define am2_T8_OUT am_model.am_SMS.am_T8_OUT
#undef am2_T9_OUT
#define am2_T9_OUT am_model.am_SMS.am_T9_OUT
#undef am2_DefSegment
#define am2_DefSegment am_model.am_SMS.am_DefSegment
#undef am2_VEHICLE_LITHO
#define am2_VEHICLE_LITHO am_model.am_SMS.am_VEHICLE_LITHO
#undef am2_CMP_OUT
#define am2_CMP_OUT am_model.am_SMS.am_CMP_OUT
#undef am2_CMP_IN
#define am2_CMP_IN am_model.am_SMS.am_CMP_IN
#undef am2_VEHICLE_CMP
#define am2_VEHICLE_CMP am_model.am_SMS.am_VEHICLE_CMP
#undef am2_INTER_LITHO
#define am2_INTER_LITHO am_model.am_SMS.am_INTER_LITHO
#undef am2_T18_OUT
#define am2_T18_OUT am_model.am_SMS.am_T18_OUT
#undef am2_T35_IN
#define am2_T35_IN am_model.am_SMS.am_T35_IN
#undef am2_T37_OUT
#define am2_T37_OUT am_model.am_SMS.am_T37_OUT
#undef am2_T28_OUT
#define am2_T28_OUT am_model.am_SMS.am_T28_OUT
#undef am2_T19_OUT
#define am2_T19_OUT am_model.am_SMS.am_T19_OUT
#undef am2_T34_IN
#define am2_T34_IN am_model.am_SMS.am_T34_IN
#undef am2_VEHICLE_ETCH
#define am2_VEHICLE_ETCH am_model.am_SMS.am_VEHICLE_ETCH
#undef am2_T29_OUT
#define am2_T29_OUT am_model.am_SMS.am_T29_OUT
#undef am2_T36_OUT
#define am2_T36_OUT am_model.am_SMS.am_T36_OUT
#undef am2_T28_IN
#define am2_T28_IN am_model.am_SMS.am_T28_IN
#undef am2_T37_IN
#define am2_T37_IN am_model.am_SMS.am_T37_IN
#undef am2_T35_OUT
#define am2_T35_OUT am_model.am_SMS.am_T35_OUT
#undef am2_T18_IN
#define am2_T18_IN am_model.am_SMS.am_T18_IN
#undef am2_T36_IN
#define am2_T36_IN am_model.am_SMS.am_T36_IN
#undef am2_T29_IN
#define am2_T29_IN am_model.am_SMS.am_T29_IN
#undef am2_T19_IN
#define am2_T19_IN am_model.am_SMS.am_T19_IN
#undef am2_T34_OUT
#define am2_T34_OUT am_model.am_SMS.am_T34_OUT
#undef am2_LITHO_PARK
#define am2_LITHO_PARK am_model.am_SMS.am_LITHO_PARK
#undef am2_T14_OUT
#define am2_T14_OUT am_model.am_SMS.am_T14_OUT
#undef am2_T26_IN
#define am2_T26_IN am_model.am_SMS.am_T26_IN
#undef am2_T24_OUT
#define am2_T24_OUT am_model.am_SMS.am_T24_OUT
#undef am2_T16_IN
#define am2_T16_IN am_model.am_SMS.am_T16_IN
#undef am2_T27_IN
#define am2_T27_IN am_model.am_SMS.am_T27_IN
#undef am2_T15_OUT
#define am2_T15_OUT am_model.am_SMS.am_T15_OUT
#undef am2_T25_OUT
#define am2_T25_OUT am_model.am_SMS.am_T25_OUT
#undef am2_T17_IN
#define am2_T17_IN am_model.am_SMS.am_T17_IN
#undef am2_T16_OUT
#define am2_T16_OUT am_model.am_SMS.am_T16_OUT
#undef am2_T24_IN
#define am2_T24_IN am_model.am_SMS.am_T24_IN
#undef am2_T26_OUT
#define am2_T26_OUT am_model.am_SMS.am_T26_OUT
#undef am2_T14_IN
#define am2_T14_IN am_model.am_SMS.am_T14_IN
#undef am2_INTER_DIFF
#define am2_INTER_DIFF am_model.am_SMS.am_INTER_DIFF
#undef am2_T17_OUT
#define am2_T17_OUT am_model.am_SMS.am_T17_OUT
#undef am2_T25_IN
#define am2_T25_IN am_model.am_SMS.am_T25_IN
#undef am2_DIFF_OUT
#define am2_DIFF_OUT am_model.am_SMS.am_DIFF_OUT
#undef am2_T15_IN
#define am2_T15_IN am_model.am_SMS.am_T15_IN
#undef am2_T27_OUT
#define am2_T27_OUT am_model.am_SMS.am_T27_OUT
#undef am2_T30_OUT
#define am2_T30_OUT am_model.am_SMS.am_T30_OUT
#undef am2_T21_OUT
#define am2_T21_OUT am_model.am_SMS.am_T21_OUT
#undef am2_T13_IN
#define am2_T13_IN am_model.am_SMS.am_T13_IN
#undef am2_T11_OUT
#define am2_T11_OUT am_model.am_SMS.am_T11_OUT
#undef am2_T23_IN
#define am2_T23_IN am_model.am_SMS.am_T23_IN
#undef am2_T22_OUT
#define am2_T22_OUT am_model.am_SMS.am_T22_OUT
#undef am2_T12_OUT
#define am2_T12_OUT am_model.am_SMS.am_T12_OUT
#undef am2_T23_OUT
#define am2_T23_OUT am_model.am_SMS.am_T23_OUT
#undef am2_T11_IN
#define am2_T11_IN am_model.am_SMS.am_T11_IN
#undef am2_T13_OUT
#define am2_T13_OUT am_model.am_SMS.am_T13_OUT
#undef am2_T21_IN
#define am2_T21_IN am_model.am_SMS.am_T21_IN
#undef am2_T30_IN
#define am2_T30_IN am_model.am_SMS.am_T30_IN
#undef am2_T12_IN
#define am2_T12_IN am_model.am_SMS.am_T12_IN
#undef am2_CMP_PARK
#define am2_CMP_PARK am_model.am_SMS.am_CMP_PARK
#undef am2_T22_IN
#define am2_T22_IN am_model.am_SMS.am_T22_IN
#undef am2_T32_IN
#define am2_T32_IN am_model.am_SMS.am_T32_IN
#undef am2_T33_OUT
#define am2_T33_OUT am_model.am_SMS.am_T33_OUT
#undef am2_T10_IN
#define am2_T10_IN am_model.am_SMS.am_T10_IN
#undef am2_T20_IN
#define am2_T20_IN am_model.am_SMS.am_T20_IN
#undef am2_T31_IN
#define am2_T31_IN am_model.am_SMS.am_T31_IN
#undef am2_T32_OUT
#define am2_T32_OUT am_model.am_SMS.am_T32_OUT
#undef am2_LITHO_OUT
#define am2_LITHO_OUT am_model.am_SMS.am_LITHO_OUT
#undef am2_T31_OUT
#define am2_T31_OUT am_model.am_SMS.am_T31_OUT
#undef am2_T20_OUT
#define am2_T20_OUT am_model.am_SMS.am_T20_OUT
#undef am2_ETCH_OUT
#define am2_ETCH_OUT am_model.am_SMS.am_ETCH_OUT
#undef am2_T10_OUT
#define am2_T10_OUT am_model.am_SMS.am_T10_OUT
#undef am2_T33_IN
#define am2_T33_IN am_model.am_SMS.am_T33_IN
#undef am2_DIFF_IN
#define am2_DIFF_IN am_model.am_SMS.am_DIFF_IN
#undef am2_parentsys
#define am2_parentsys am_model.am_SMS.am_parentsys
#undef am2_INTER_PARK
#define am2_INTER_PARK am_model.am_SMS.am_INTER_PARK
#undef am2_INTER_CMP
#define am2_INTER_CMP am_model.am_SMS.am_INTER_CMP
#undef am2_T9_IN
#define am2_T9_IN am_model.am_SMS.am_T9_IN
#undef am2_T8_IN
#define am2_T8_IN am_model.am_SMS.am_T8_IN
#undef am2_ETCH_PARK
#define am2_ETCH_PARK am_model.am_SMS.am_ETCH_PARK
#undef am2_T3_IN
#define am2_T3_IN am_model.am_SMS.am_T3_IN
#undef am2_ETCH_IN
#define am2_ETCH_IN am_model.am_SMS.am_ETCH_IN
#undef am2_T4_IN
#define am2_T4_IN am_model.am_SMS.am_T4_IN
#undef am2_T6_IN
#define am2_T6_IN am_model.am_SMS.am_T6_IN
#undef am2_T5_IN
#define am2_T5_IN am_model.am_SMS.am_T5_IN
#undef am2_T7_IN
#define am2_T7_IN am_model.am_SMS.am_T7_IN
#undef am2_DIFF_PARK
#define am2_DIFF_PARK am_model.am_SMS.am_DIFF_PARK
#undef am2_T2_IN
#define am2_T2_IN am_model.am_SMS.am_T2_IN
#undef am2_T1_IN
#define am2_T1_IN am_model.am_SMS.am_T1_IN
#undef GetSocketNonBlocking
#undef XLClear
#undef OPCFlushWrite
#undef OPCInit
#undef SetSocketMessages
#undef Fsysdisplay
#undef OPCWriteIntegerWait
#undef Fsetpathtime
#undef SendSocketString
#undef GetSocketTimeOut
#undef FsetStartDate
#undef MMSyncSendMessageNumReals
#undef OPCListConnections
#undef MMSyncSendMessageNumIntegers
#undef XLClearAreaR1C1
#undef MMSyncSendMessagePrint
#undef AcceptSocketService
#undef XLClearR1C1
#undef SetSocketNonBlocking
#undef DBGetErrMsg
#undef am2_die
#define am2_die am_model.am_die
#undef FtranQueue
#undef Fquetoggle
#undef OPCWriteStringWait
#undef am2_stream_LoadA_1
#define am2_stream_LoadA_1 am_model.am_stream_LoadA_1
#undef XLGetAreaA1
#undef XLSetA1
#undef SetSocketTimeOut
#undef FtranResource
#undef DBOpenSession
#undef MMSyncReadMessagePrint
#undef FscaleQueue
#undef MMSyncReadMessageNumIntegers
#undef MMSyncReadMessageNumReals
#undef MMSyncSendMessageString
#undef MilliSleep
#undef SetAcceptTimeOut
#undef ValidSocket
#undef MMSyncSendMessageClear
#undef FattachRes
#undef AdjacentLocs
#undef am2_Makespan
#define am2_Makespan am_model.am_Makespan
#undef am2_TOOLS
#define am2_TOOLS am_model.am_TOOLS
#undef OPCReadInteger
#undef DBMoveLast
#undef MMSyncReadMessageString
#undef DBMoveFirst
#undef LocPathName
#undef Fchangename
#undef XLGetAreaR1C1
#undef GetAnimate
#undef FgetModelDate
#undef XLSetAreaA1
#undef am2_OPCTimestamp
#define am2_OPCTimestamp am_model.am_OPCTimestamp
#undef FireUserEvent
#undef ConnectSocketPort
#undef OPCDisconnect
#undef GetSocketNum
#undef ConnectSocketService
#undef FcolorElement
#undef OPCWriteString
#undef XLGetA1
#undef CurPath
#undef MMSyncSendMessage
#undef DBGetColumnName
#undef Fresvis
#undef DBMovePrev
#undef GetSocketHost
#undef FattachRobot
#undef MMSyncReadMessageStringLength
#undef OPCAddGroup
#undef am2_P_Enter_A
#define am2_P_Enter_A am_model.am_P_Enter_A
#undef Fvehdisplay
#undef OPCWriteInteger
#undef FrotResource
#undef FcopyQueuePict
#undef FgetStartDate
#undef XLSetAreaR1C1
#undef ReadSocketString
#undef FrotQueue
#undef LocPath
#undef OPCReadReal
#undef am2_modelsys
#define am2_modelsys am_model.am_modelsys
#undef OPCSubscribe
#undef XLClearArea
#undef MachineName
#undef OPCConnectServer
#undef MMSyncSendMessageReal
#undef DBOpenSourceUDL
#undef OPCWriteRealWait
#undef MMSyncSendMessageInteger
#undef XLClearColumnC1
#undef DistLoc2Loc
#undef XLClearAreaA1
#undef OPCReadString
#undef DBOpenSource
#undef MMSyncReadMessageReal
#undef FattachLabel
#undef XLSetR1C1
#undef XLClearA1
#undef DBGetRowData
#undef XLGet
#undef OPCListItems
#undef DBGetColumnCount
#undef MMSyncReadMessageInteger
#undef XLClearRow
#undef ClosestVehDests
#undef AcceptSocketPort
#undef FgetNavDist
#undef am2_P_Proc_A
#define am2_P_Proc_A am_model.am_P_Proc_A
#undef am2_stream_TOOLS_1
#define am2_stream_TOOLS_1 am_model.am_stream_TOOLS_1
#undef MMSyncReadMessageType
#undef XLClearWorkbook
#undef am2_stream0
#define am2_stream0 am_model.am_stream0
#undef SetNumAcceptsPort
#undef SetNumAcceptsService
#undef SetAcceptBlocking
#undef XLGetArea
#undef DBExecuteCmd
#undef FcopyLoadTypePict
#undef MMSyncSendMessageType
#undef SetSyncRate
#undef OPCAddItem
#undef XLClearSheet
#undef Fquevis
#undef SetConnectTimeOut
#undef MMSyncSendMessageNumDatas
#undef FauthToolSimModule
#undef CloseSocket
#undef XLSet
#undef XLGetR1C1
#undef DBCloseSession
#undef OPCRefreshSubscription
#undef OPCWriteReal
#undef MMSyncSendMessageModel
#undef am2_SMS
#define am2_SMS am_model.am_SMS.$sys
#undef SetConnectBlocking
#undef DBMoveNext
#undef GetActiveXRunning
#undef XLClose
#undef XLClearColumnA1
#undef MMSyncReadMessageTime
#undef FscaleResource
#undef GetSocketName
#undef XLSetArea
#undef ClosestVehicles
#undef am2_Queue
#define am2_Queue am_model.am_Queue
#undef DBCloseSource
#undef Fsaa_on
#undef MMSyncSendMessageNumStrings
#undef Fdelpic
#undef DistVeh2Loc
#undef Fgetsysdate
#undef FtoggleSolid
#undef Fsystem_seconds
#undef FattachQueue
#undef am2_OPCQuality
#define am2_OPCQuality am_model.am_OPCQuality
#undef MMSyncReadMessageNumStrings
#undef Fmodnavi
#undef Ftogglepict
#undef SetDisplayStep
